<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">
      <img src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.freepik.es%2Fvector-premium%2Fvector-icono-linea-servicio-al-cliente-servicio-integral-atencion-al-cliente-mano-personas-ilustracion-vectorial_18321327.htm&psig=AOvVaw2mEGdSZ3fD06p9PJsmCFtH&ust=1697036091369000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCID-zJ3e64EDFQAAAAAdAAAAABAE" alt="" width="30" height="24" class="d-inline-block align-text-top">
      Clientes
    </a>
  </div>
</nav>
<div class="container">
    <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center">
        <h1>Listado de Clientes</h1>

        <a href="<?php echo e(route('nuevo')); ?>" class="btn btn-warning" style="background-color: red;">Nuevo</a>
    </div>
    <div class="input-group mb-3">
        <form action="<?php echo e(route('buscar')); ?>"class="d-flex">
        <input name="buscar" class="form-control me-1" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-primary" type="submit">Search</button>
      </form>
    </div>

    <?php
    $vacio = isset($vacio) ? $vacio : false;
    ?>

    <?php if($vacio): ?>
    <div class="card">
        <div class="card.body">
            <center><a class="card-text">No se encontró el resultado de la búsqueda.</a></center>
        </div>
    </div>
    <?php else: ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Edad</th>
                <th>CI</th>
                <th>Correo</th>
                <th>Fecha de Nacimiento</th>
                <th>Estado</th>
                <th>Accion</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->id ?? 'NN'); ?></td>
                <td><?php echo e($cliente->nombre ?? 'NN'); ?></td>
                <td><?php echo e($cliente->apellido ?? 'NN'); ?></td>
                <td><?php echo e($cliente->edad ?? 'NN'); ?></td>
                <td><?php echo e($cliente->ci ?? 'NN'); ?></td>
                <td><?php echo e($cliente->correo ?? 'NN'); ?></td>
                <td><?php echo e($cliente->fecha_nac ?? 'NN'); ?></td>
                <td>
                    <?php if($cliente->estado == 'Activo'): ?>
                    <span class="badge badge-primary"><?php echo e($cliente->estado); ?></span>
                    <?php elseif($cliente->estado == 'activo'): ?>
                    <span class="badge badge-primary"><?php echo e($cliente->estado); ?></span>
                    <?php else: ?>
                    <span class="badge badge-warning"><?php echo e($cliente->estado); ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('eliminar', ['id' => $cliente->id])); ?>"
                        onclick="return confirm('¿Estás seguro de que deseas eliminar este usuario?');"
                        class="btn btn-danger">Eliminar
                    </a>
                    <a href="<?php echo e(route('editar', ['id' => $cliente->id])); ?>" class="btn btn-warning">Editar</a>
                    <a href="<?php echo e(route('ver', ['id' => $cliente->id])); ?>" class="btn btn-info">Ver</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\ACER ASPIRE 3\OneDrive\Escritorio\Rose\analisis de sistemas\tercer año\6to semestre\Diseño y Programacion web III\dw3\resources\views/clientes/index.blade.php ENDPATH**/ ?>